package org.example

import org.example.crud.criarTabelaCaixa
import org.example.ui.menu

fun main() {
    criarTabelaCaixa()
    menu()
}