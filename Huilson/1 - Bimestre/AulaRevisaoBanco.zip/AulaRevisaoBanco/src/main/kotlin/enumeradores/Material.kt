package org.example.enumeradoras

enum class Material {
    PLASTICO, PVC, METAL, ARGAMASSA
}