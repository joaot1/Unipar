package org.example.enumeradoras

enum class Setor{
    FINANCEIRO, ADMINISTRACAO, LOGISTICA, MONTAGEM
}