package org.example.enumeradoras

enum class Sexo {
    MASCULINO, FEMENINO
}