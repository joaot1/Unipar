package org.example.enumeradoras

enum class Funcao {
    CONTADOR, ASSISTENTE, OPERADOR, CARREGADOR
}